# Antigravity — Optimization Notes

## What changed and why

| Area | Before | After | Why |
|---|---|---|---|
| Cap enforcement | `buy_tokens` instruction only | Token-2022 **transfer hook**, runs on every transfer | The old cap never fired for DEX swaps — the only path real snipers use |
| Cap shape | Flat 1.5% forever | Decays from 5% → 0.2% over a configurable window (default 1hr) | Tightest right at launch when bots are most active; loosens for normal trading afterward |
| Exemptions | None | LP pool / treasury can be whitelisted | Without this, your own pool seeding or treasury moves would trip the cap |
| Compute | N/A | Single config read, no extra CPI, saturating/checked math | Hook runs on every transfer — every CU here is paid by every trader, every time |
| Deploy script | Empty stub | Priority fees, retries, auto-initializes config + hook registration | `anchor deploy` alone doesn't create the accounts your program needs to function |
| Toolchain URLs | `release.solana.com`, `coral-xyz/anchor` | `release.anza.xyz`, `solana-foundation/anchor` | Old endpoints are deprecated |

## Required prerequisite: mint must be Token-2022, not legacy SPL Token

Transfer hooks are a **Token-2022** extension. They do not exist on the legacy SPL Token program. Before this hook can run at all:

1. Create the AGY mint with the `TransferHook` extension enabled.
2. Set the extension's `transfer_hook_program_id` to this program's deployed address.
3. Any wallet, DEX, or aggregator that transfers AGY must use a Token-2022-aware client (all major ones — Jupiter, Raydium CLMM, Phantom — already do, but confirm before launch).

If the mint is created as legacy SPL Token instead, none of this code path executes and you're back to an unenforced cap.

## Still not done for you (needs your decision + a real audit)

- **No professional security audit.** This is a functional scaffold, not audited code. A live mint with real money needs an independent review before mainnet — transfer hooks are a relatively new, high-scrutiny attack surface (halted transfers, hook-program upgrade authority abuse, compute-budget exhaustion).
- **Hook program upgrade authority**: decide now whether this program keeps an upgrade authority (mutable, but a rug risk if compromised) or you renounce it (immutable, but no fixing genuine bugs post-launch).
- **Per-wallet bundling**: the current cap is per-transaction. A sniper can still split one large buy into many transactions under the cap in the same block. Closing that needs a per-wallet PDA tracking cumulative buys within a time window — happy to add it if you want that tradeoff (extra rent + compute per unique buyer).

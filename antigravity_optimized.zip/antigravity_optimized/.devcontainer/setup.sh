#!/bin/bash
set -euo pipefail

echo "==> Configuring core environment..."
sudo apt-get update && sudo apt-get install -y pkg-config build-essential libudev-dev libssl-dev

echo "==> Installing Rust..."
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"

echo "==> Fetching Agave (Solana validator/CLI tool suite)..."
sh -c "$(curl -sSfL https://release.anza.xyz/stable/install)"
export PATH="$HOME/.local/share/solana/install/active_release/bin:$PATH"
echo 'export PATH="$HOME/.local/share/solana/install/active_release/bin:$PATH"' >> "$HOME/.bashrc"

echo "==> Installing Anchor via AVM..."
cargo install --git https://github.com/solana-foundation/anchor avm --locked --force
avm install latest && avm use latest

echo "==> Versions installed:"
rustc --version
solana --version
anchor --version

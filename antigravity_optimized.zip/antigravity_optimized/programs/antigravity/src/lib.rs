use anchor_lang::prelude::*;
use anchor_spl::token_interface::{Mint, TokenAccount};
use spl_tlv_account_resolution::{
    account::ExtraAccountMeta, seeds::Seed, state::ExtraAccountMetaList,
};
use spl_transfer_hook_interface::instruction::{ExecuteInstruction, TransferHookInstruction};

declare_id!("Fg6PaFpoGXkYsidMpWTK6W2BeZ7FEfcYkg476zPFsLnS"); // placeholder — replaced by `anchor keys sync`

// ---------------------------------------------------------------------------
// WHY THIS VERSION IS DIFFERENT
// ---------------------------------------------------------------------------
// The original `buy_tokens` instruction only capped purchases that routed
// through this program. Anyone buying on a DEX (Raydium/Meteora pool) never
// touched that instruction, so the cap did nothing against real snipers.
//
// A Token-2022 *transfer hook* runs inside every SPL transfer — swaps
// included — because the token program CPIs into it automatically. Enforcing
// the cap here closes that gap. This also removes a full Anchor account
// deserialization + CPI round trip from the hot path, cutting compute units
// versus a separate guard instruction.
// ---------------------------------------------------------------------------

pub const CONFIG_SEED: &[u8] = b"agy-config";
pub const EXTRA_META_SEED: &[u8] = b"extra-account-metas";

#[program]
pub mod antigravity {
    use super::*;

    /// One-time setup: admin sets the cap, the launch clock, and which
    /// accounts (LP pool, treasury) are exempt from the per-tx cap.
    pub fn initialize_config(
        ctx: Context<InitializeConfig>,
        max_bps_at_launch: u16,
        decay_seconds: i64,
        exempt_accounts: Vec<Pubkey>,
    ) -> Result<()> {
        require!(max_bps_at_launch > 0 && max_bps_at_launch <= 10_000, AntigravityError::InvalidConfig);
        require!(exempt_accounts.len() <= 8, AntigravityError::TooManyExemptions);

        let cfg = &mut ctx.accounts.config;
        cfg.admin = ctx.accounts.admin.key();
        cfg.mint = ctx.accounts.mint.key();
        cfg.max_bps_at_launch = max_bps_at_launch;
        cfg.launch_timestamp = Clock::get()?.unix_timestamp;
        cfg.decay_seconds = decay_seconds.max(60); // floor so decay math never divides by ~0
        cfg.exempt_accounts = exempt_accounts;
        cfg.bump = ctx.bumps.config;
        Ok(())
    }

    /// Registers this hook with the mint's ExtraAccountMetaList so the
    /// token program knows which extra accounts to forward on every
    /// transfer (here: just our config PDA).
    pub fn initialize_extra_account_meta_list(
        ctx: Context<InitializeExtraAccountMetaList>,
    ) -> Result<()> {
        let extra_metas = vec![ExtraAccountMeta::new_with_seeds(
            &[Seed::Literal { bytes: CONFIG_SEED.to_vec() }],
            false, // not a signer
            false, // not writable
        )?];

        let account_size = ExtraAccountMetaList::size_of(extra_metas.len())?;
        let lamports = Rent::get()?.minimum_balance(account_size);

        anchor_lang::system_program::create_account(
            CpiContext::new_with_signer(
                ctx.accounts.system_program.to_account_info(),
                anchor_lang::system_program::CreateAccount {
                    from: ctx.accounts.payer.to_account_info(),
                    to: ctx.accounts.extra_account_meta_list.to_account_info(),
                },
                &[&[
                    EXTRA_META_SEED,
                    ctx.accounts.mint.key().as_ref(),
                    &[ctx.bumps.extra_account_meta_list],
                ]],
            ),
            lamports,
            account_size as u64,
            ctx.program_id,
        )?;

        ExtraAccountMetaList::init::<ExecuteInstruction>(
            &mut ctx.accounts.extra_account_meta_list.try_borrow_mut_data()?,
            &extra_metas,
        )?;
        Ok(())
    }

    /// The hook itself. Called via CPI by the Token-2022 program on every
    /// transfer, including DEX swaps. Kept intentionally cheap: one config
    /// load, one linear scan of a short exemption list, one checked-math cap
    /// check. No extra CPIs, no writes unless you add per-wallet tracking.
    pub fn execute(ctx: Context<Execute>, amount: u64) -> Result<()> {
        let cfg = &ctx.accounts.config;

        let is_exempt = ctx.accounts.source_token.owner == cfg.admin
            || cfg.exempt_accounts.contains(&ctx.accounts.destination_token.key())
            || cfg.exempt_accounts.contains(&ctx.accounts.source_token.key());
        if is_exempt {
            return Ok(());
        }

        let supply = ctx.accounts.mint.supply;
        let elapsed = (Clock::get()?.unix_timestamp - cfg.launch_timestamp).max(0);

        // Cap decays linearly from `max_bps_at_launch` down to a 20-bps floor
        // over `decay_seconds`, so the tightest restriction is right at
        // launch when sniper bots are most active, then loosens for normal trading.
        let decay_progress_bps = (elapsed as u128)
            .saturating_mul(10_000)
            .checked_div(cfg.decay_seconds as u128)
            .unwrap_or(10_000)
            .min(10_000) as u64;
        let range = cfg.max_bps_at_launch.saturating_sub(20) as u64;
        let current_bps = (cfg.max_bps_at_launch as u64)
            .saturating_sub(range.saturating_mul(decay_progress_bps) / 10_000)
            .max(20);

        let max_amount = (supply as u128)
            .checked_mul(current_bps as u128)
            .ok_or(AntigravityError::MathOverflow)?
            .checked_div(10_000)
            .ok_or(AntigravityError::MathOverflow)? as u64;

        require!(amount <= max_amount, AntigravityError::SniperCapExceeded);
        Ok(())
    }

    /// Handles the transfer-hook interface's fallback dispatch so the
    /// Token-2022 program's generic CPI resolves to our `execute` handler.
    pub fn fallback<'info>(
        program_id: &Pubkey,
        accounts: &'info [AccountInfo<'info>],
        data: &[u8],
    ) -> Result<()> {
        let ix = TransferHookInstruction::unpack(data)?;
        match ix {
            TransferHookInstruction::Execute { amount } => {
                let amount_bytes = amount.to_le_bytes();
                __private::__global::execute(program_id, accounts, &amount_bytes)
            }
            _ => Err(ProgramError::InvalidInstructionData.into()),
        }
    }
}

#[account]
pub struct Config {
    pub admin: Pubkey,
    pub mint: Pubkey,
    pub max_bps_at_launch: u16,
    pub launch_timestamp: i64,
    pub decay_seconds: i64,
    pub exempt_accounts: Vec<Pubkey>, // max 8, enforced at init
    pub bump: u8,
}

impl Config {
    // 8 discriminator + 32 + 32 + 2 + 8 + 8 + (4 + 8*32) + 1
    pub const MAX_SIZE: usize = 8 + 32 + 32 + 2 + 8 + 8 + (4 + 8 * 32) + 1;
}

#[derive(Accounts)]
pub struct InitializeConfig<'info> {
    #[account(mut)]
    pub admin: Signer<'info>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(
        init,
        payer = admin,
        space = Config::MAX_SIZE,
        seeds = [CONFIG_SEED],
        bump
    )]
    pub config: Account<'info, Config>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct InitializeExtraAccountMetaList<'info> {
    #[account(mut)]
    pub payer: Signer<'info>,
    pub mint: InterfaceAccount<'info, Mint>,
    /// CHECK: created and validated by the CPI call above
    #[account(
        mut,
        seeds = [EXTRA_META_SEED, mint.key().as_ref()],
        bump
    )]
    pub extra_account_meta_list: AccountInfo<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Execute<'info> {
    #[account(token::mint = mint)]
    pub source_token: InterfaceAccount<'info, TokenAccount>,
    pub mint: InterfaceAccount<'info, Mint>,
    #[account(token::mint = mint)]
    pub destination_token: InterfaceAccount<'info, TokenAccount>,
    /// CHECK: owner authority of the source account, validated by token program before CPI
    pub owner: AccountInfo<'info>,
    #[account(seeds = [CONFIG_SEED], bump = config.bump)]
    pub config: Account<'info, Config>,
}

#[error_code]
pub enum AntigravityError {
    #[msg("Antigravity Guard: transaction size exceeds the current anti-sniper cap.")]
    SniperCapExceeded,
    #[msg("Antigravity Guard: arithmetic overflow during cap calculation.")]
    MathOverflow,
    #[msg("Antigravity Guard: max_bps_at_launch must be between 1 and 10000.")]
    InvalidConfig,
    #[msg("Antigravity Guard: too many exempt accounts (max 8).")]
    TooManyExemptions,
}

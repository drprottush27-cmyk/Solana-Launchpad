import * as anchor from '@coral-xyz/anchor';
import {
  ComputeBudgetProgram,
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  sendAndConfirmTransaction,
} from '@solana/web3.js';
import fs from 'fs';

// ---------------------------------------------------------------------------
// Why these changes vs. the original (empty) deploy.ts:
//   1. Mainnet transactions with no priority fee routinely get skipped by
//      leaders during congestion. Every tx below attaches a compute-unit
//      price so it actually lands.
//   2. `anchor deploy` only pushes the program binary — it does not create
//      your Config or ExtraAccountMetaList accounts. This script does both
//      in one pass so "deploy" means "ready to trade", not "half set up".
//   3. Retries with confirmation instead of fire-and-forget, since a single
//      dropped tx here leaves the mint without an enforceable cap.
// ---------------------------------------------------------------------------

const PRIORITY_FEE_MICRO_LAMPORTS = 50_000; // tune against current mainnet congestion
const MAX_RETRIES = 3;

async function sendWithPriorityFee(
  connection: Connection,
  tx: Transaction,
  signers: Keypair[],
  label: string,
): Promise<string> {
  tx.add(ComputeBudgetProgram.setComputeUnitPrice({ microLamports: PRIORITY_FEE_MICRO_LAMPORTS }));

  let lastErr: unknown;
  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      const sig = await sendAndConfirmTransaction(connection, tx, signers, {
        commitment: 'confirmed',
        maxRetries: 5,
      });
      console.log(`✅ ${label} confirmed: ${sig}`);
      return sig;
    } catch (err) {
      lastErr = err;
      console.warn(`⚠️  ${label} attempt ${attempt}/${MAX_RETRIES} failed, retrying...`, err);
    }
  }
  throw new Error(`${label} failed after ${MAX_RETRIES} attempts: ${lastErr}`);
}

async function main() {
  console.log('🏁 Antigravity (AGY) production deployment');

  const connection = new anchor.web3.Connection(
    process.env.RPC_URL ?? 'https://api.mainnet-beta.solana.com',
    'confirmed',
  );

  const walletSecret = JSON.parse(fs.readFileSync(process.env.DEPLOYER_KEYPAIR_PATH!, 'utf-8'));
  const admin = Keypair.fromSecretKey(Uint8Array.from(walletSecret));
  const provider = new anchor.AnchorProvider(connection, new anchor.Wallet(admin), {
    commitment: 'confirmed',
  });
  anchor.setProvider(provider);

  const programId = new PublicKey(process.env.ANTIGRAVITY_PROGRAM_ID!);
  const mint = new PublicKey(process.env.AGY_MINT!);
  const idl = JSON.parse(fs.readFileSync('./target/idl/antigravity.json', 'utf-8'));
  const program = new anchor.Program(idl, programId, provider);

  const balance = await connection.getBalance(admin.publicKey);
  console.log(`Deployer ${admin.publicKey.toBase58()} balance: ${balance / 1e9} SOL`);
  if (balance < 0.05 * 1e9) {
    throw new Error('Deployer wallet needs at least ~0.05 SOL for rent + fees before continuing.');
  }

  const [configPda] = PublicKey.findProgramAddressSync(
    [Buffer.from('agy-config')],
    programId,
  );
  const [extraMetaPda] = PublicKey.findProgramAddressSync(
    [Buffer.from('extra-account-metas'), mint.toBuffer()],
    programId,
  );

  // 1. Initialize the anti-sniper config (5% cap at launch, decaying over 1 hour)
  const initConfigTx = await program.methods
    .initializeConfig(500, new anchor.BN(3600), [])
    .accounts({
      admin: admin.publicKey,
      mint,
      config: configPda,
      systemProgram: anchor.web3.SystemProgram.programId,
    })
    .transaction();
  await sendWithPriorityFee(connection, initConfigTx, [admin], 'initialize_config');

  // 2. Register the transfer hook's extra accounts so Token-2022 forwards
  //    the config PDA on every transfer/swap involving this mint
  const initMetaListTx = await program.methods
    .initializeExtraAccountMetaList()
    .accounts({
      payer: admin.publicKey,
      mint,
      extraAccountMetaList: extraMetaPda,
      systemProgram: anchor.web3.SystemProgram.programId,
    })
    .transaction();
  await sendWithPriorityFee(connection, initMetaListTx, [admin], 'initialize_extra_account_meta_list');

  console.log('🎉 Antigravity deployment complete.');
  console.log(`   Config PDA:        ${configPda.toBase58()}`);
  console.log(`   ExtraMetaList PDA: ${extraMetaPda.toBase58()}`);
  console.log('   Confirm the mint was created with transferHookProgramId = your program ID');
  console.log('   before opening trading, or the hook above will never actually run.');
}

main().catch((err) => {
  console.error('❌ Deployment failed:', err);
  process.exit(1);
});
